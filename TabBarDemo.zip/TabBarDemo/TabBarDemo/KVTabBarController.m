//
//  KVTabBarController.m
//  Test
//
//  Created by like on 16/11/18.
//  Copyright © 2016年 Kevie.Bisco. All rights reserved.
//

#import "KVTabBarController.h"

#define tabBarDefaultTag 10000
@interface KVTabBarController ()

@property(nonatomic,strong)UIView *k_tabBar;

@property(nonatomic,strong)UIView *k_shadeView;

@property(nonatomic,strong)UIButton *k_selectBtn;

@property(nonatomic,copy)NSArray<UIViewController *> *defaultViewControllers;


@end

@implementation KVTabBarController

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.barMaxItems = 5;
        //隐藏系统自带的tabBar
        self.tabBar.hidden = YES;
    }
    return self;
}

-(void)loadView{
    [super loadView];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self createNewTabBar];
    [self createShadeView];
}

//!创建遮罩
-(void)createShadeView{
    
    self.k_shadeView = [[UIView alloc]initWithFrame:self.view.bounds];
    self.k_shadeView.alpha = 0.8;
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:self.k_shadeView.bounds];
    toolbar.barStyle = UIBarStyleBlackOpaque;
    toolbar.translucent = NO;
    [_k_shadeView addSubview:toolbar];
    self.k_shadeView.hidden = YES;
    [self.view addSubview:self.k_shadeView];
    [self.view insertSubview:_k_shadeView belowSubview:self.k_tabBar];
}

//!创建新的tabBar
-(void)createNewTabBar{
    self.k_tabBar = [[UIView alloc]initWithFrame:self.tabBar.frame];
    _k_tabBar.backgroundColor = self.tabBar.barTintColor;
    [self.view addSubview:_k_tabBar];
}
//!设置新tabbar背景时候不在使用barTinColor
-(void)setTabBarBackgroundColor:(UIColor *)tabBarBackgroundColor{
    _tabBarBackgroundColor = tabBarBackgroundColor;
    _k_tabBar.backgroundColor = tabBarBackgroundColor;
}

//!重写子类setViewControllers
-(void)setViewControllers:(NSArray<__kindof UIViewController *> *)viewControllers{
    //!存储所有控制视图
    self.defaultViewControllers = [viewControllers copy];
    
    //只让标签栏最多只显示5个，并且去除掉系统自带的更多按钮效果。
    if(viewControllers.count >= _barMaxItems){
        _barMaxItems = 5;
    }else{
        _barMaxItems = viewControllers.count;
    }
    
    //这里最多只将5个元素放入标签栏，其他则在中间点击后展示
    [super setViewControllers:[_defaultViewControllers subarrayWithRange:(NSRange){0,_barMaxItems}]];
    
    //创建标签栏显示标签按钮
    for (int i = 0; i < _defaultViewControllers.count; i++) {
        if ( i >= _barMaxItems) {
            [self createHidenBarItemButtonWithTag:tabBarDefaultTag+i];
        }else{
            UIButton *button = [self createBarItemButtonWithTag:tabBarDefaultTag+i];
            static CGFloat x = 0;
            if (_barMaxItems%2 == 0) {
                button.frame = CGRectMake(x + 1, 1, CGRectGetWidth(_k_tabBar.frame)/_barMaxItems - 1, CGRectGetHeight(_k_tabBar.frame) - 2);
                x = CGRectGetMaxX(button.frame);
            }else{
                if (i == _barMaxItems/2) {
                    button.frame = CGRectMake(x+1, -20, 49+20-1,49+20-1);
                    button.layer.cornerRadius = CGRectGetWidth(button.frame)/2.0f;
                    x = CGRectGetMaxX(button.frame);
                }else{
                    button.frame = CGRectMake(x + 1, 1, (CGRectGetWidth(_k_tabBar.frame) - (49+20))/(_barMaxItems - 1) -1.2, CGRectGetHeight(_k_tabBar.frame) - 2);
                    x = CGRectGetMaxX(button.frame);
                }
            }
            if (i == 0) {
                button.selected = YES;
                self.k_selectBtn = button;
            }
        }
    }
}

#pragma mark 创建显示在标签栏的按钮
-(UIButton *)createBarItemButtonWithTag:(NSInteger)tag{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    UITabBarItem *item = self.tabBar.items[tag-tabBarDefaultTag];
    [button setTitle:item.title forState:UIControlStateNormal];
    [button setImage:item.image forState:UIControlStateNormal];
    [button setImage:item.selectedImage forState:UIControlStateSelected];
    [button setBackgroundColor:[UIColor greenColor]];
    button.layer.cornerRadius = 5;
    button.layer.masksToBounds = YES;
    [button addTarget:self action:@selector(barItemSelected:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = tag;
    [self.k_tabBar addSubview:button];
    return button;
}
//!创建隐藏的标签栏按钮
-(void)createHidenBarItemButtonWithTag:(NSInteger)tag{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.tag = tag;
    button.frame = CGRectMake(0, 0, 49, 49);
    button.center = CGPointMake(_k_tabBar.center.x, _k_tabBar.center.y);
    button.backgroundColor = [UIColor blueColor];
    button.layer.cornerRadius = CGRectGetWidth(button.frame)/2.0f;
    [button setTitle:[NSString stringWithFormat:@"%ld",tag] forState:UIControlStateNormal];
    button.hidden = NO;
    [button addTarget:self action:@selector(hidenBarItemButtonEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.k_shadeView addSubview:button];
}

#pragma mark 隐藏标签按钮事件
-(void)hidenBarItemButtonEvent:(UIButton *)button{
    UINavigationController *nav = (UINavigationController *)self.defaultViewControllers[button.tag -tabBarDefaultTag];
    //[self moreItemsDisApear:(UIButton *)[self.view.window viewWithTag:_barMaxItems/2]];
    [self barItemSelected:((UIButton *)[self.view.window viewWithTag:tabBarDefaultTag + self.selectedIndex])];
    [self.selectedViewController presentViewController:nav animated:YES completion:^{
        UIViewController *vc = nav.viewControllers[0];
        vc.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"exit" style:UIBarButtonItemStyleDone target:self action:@selector(exitViewController:)];
    }];

}

-(void)exitViewController:(UIBarButtonItem *) barbutton{
    //NSLog(@"\\\%ld,%ld",self.selectedIndex,self.k_selectBtn.tag);
    [barbutton.target dismissViewControllerAnimated:YES completion:^{
       
    }];
}
#pragma mark 标签栏按钮点击事件
-(void)barItemSelected:(UIButton *)button{
    //NSLog(@"%ld",self.selectedIndex);
    //！如果当选中中间按钮的时候，则弹出更多的标签（只有显示栏为奇数或者大于5的时候才可以触发次效果）
    if ((button.tag - tabBarDefaultTag) == _barMaxItems/2 && _barMaxItems%2 != 0) {
        if (button.selected) {
            [self moreItemsDisApear:button];
        }else{
            [self moreItemsApear:button];
        }
    }else{
        //上一个选择为特殊按钮时并且是奇数时，则需要隐藏
        if ((self.k_selectBtn.tag-tabBarDefaultTag) == _barMaxItems/2 && _barMaxItems%2 != 0) {
            [self moreItemsDisApear:self.k_selectBtn];
        }
        self.selectedIndex = button.tag - tabBarDefaultTag;
    }
    self.k_selectBtn.selected = NO;
    button.selected = YES;
    self.k_selectBtn = button;
}
-(void)moreItemsApear:(UIButton *)button{
    [self.view insertSubview:self.k_shadeView belowSubview:self.k_tabBar];
    self.k_shadeView.hidden = NO;
    
    for (NSInteger i = _barMaxItems; i < _defaultViewControllers.count; i++) {
        UIButton *currentButton = (UIButton *)[self.view.window viewWithTag:i+tabBarDefaultTag];
        currentButton.hidden = NO;
        [UIView animateWithDuration:0.5 animations:^{
            CGPoint center = currentButton.center;
            CGFloat x = 100*((_defaultViewControllers.count-_barMaxItems)/3)*cos(-M_PI+(i-_barMaxItems+1)*M_PI/(_defaultViewControllers.count - _barMaxItems+1));
            CGFloat y = 100*((_defaultViewControllers.count-_barMaxItems)/3)*sin(-M_PI+(i-_barMaxItems+1)*M_PI/(_defaultViewControllers.count - _barMaxItems +1));
            currentButton.center = CGPointMake(center.x+x, y+center.y);
            
        }];
    }
}

-(void)moreItemsDisApear:(UIButton *)button{
    
    button.selected = NO;
    for (NSInteger i = _barMaxItems; i < _defaultViewControllers.count; i++) {
        UIButton *currentBtn = (UIButton *)[self.view.window viewWithTag:i+tabBarDefaultTag];
        [UIView animateWithDuration:0.5 animations:^{
            currentBtn.center = CGPointMake(_k_tabBar.center.x, _k_tabBar.center.y);
        } completion:^(BOOL finished) {
            currentBtn.hidden = YES;
            self.k_shadeView.hidden = YES;
        }];
    }
}

-(void)setCurrentIndex:(NSInteger)currentIndex{
    _currentIndex = currentIndex;
    if (currentIndex >_barMaxItems) {
        //这里使用异步为了防止控制视图没加载完就跳转的bug
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            // 耗时的操作
            dispatch_async(dispatch_get_main_queue(), ^{
                // 更新界面
                [self hidenBarItemButtonEvent:(UIButton *)[self.view.window viewWithTag:tabBarDefaultTag+currentIndex]];
            });
        });
    }else{
        [self barItemSelected:(UIButton *)[self.view.window viewWithTag:tabBarDefaultTag+currentIndex]];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
