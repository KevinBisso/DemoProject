//
//  AppDelegate.m
//  TabBarDemo
//
//  Created by like on 16/11/18.
//  Copyright © 2016年 Kevie.Bisco. All rights reserved.
//

#import "AppDelegate.h"
#import "KVTabBarController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    NSMutableArray *navs = [NSMutableArray array];
    for (int i=0; i <12; i++) {
        UIViewController *vc = [[UIViewController alloc]init];
        vc.view.backgroundColor = [UIColor colorWithRed:arc4random()%256/255.0f green:arc4random()%256/255.0f blue:arc4random()%256/255.0f alpha:1];
        vc.title = [NSString stringWithFormat:@"test+%d",i];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:vc];
        nav.tabBarItem = [[UITabBarItem alloc]initWithTitle:[NSString stringWithFormat:@"test+%d",i] image:nil tag:1000+i];
        [navs addObject:nav];
    }
    KVTabBarController *lktabBarC =[[KVTabBarController alloc]init];
    lktabBarC.tabBarBackgroundColor = [UIColor yellowColor];
    _window.rootViewController = lktabBarC;
    //navs 为偶数个的时候默认为不同样式，为奇数时则中间一个可以访问更多，建议不要超过12个（否则有些将会超出显示范围）。
    lktabBarC.viewControllers = navs;
    //lktabBarC.currentIndex = 7;//设置当前显示的视图,这个必须设置viewControllers
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
