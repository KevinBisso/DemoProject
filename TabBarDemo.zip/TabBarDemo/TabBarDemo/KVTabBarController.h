//
//  KVTabBarController.h
//  Test
//
//  Created by like on 16/11/18.
//  Copyright © 2016年 Kevie.Bisco. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KVTabBarController : UITabBarController

//!标签栏背景颜色
@property(nonatomic,strong)UIColor *tabBarBackgroundColor;

//!标签栏最大容量为5，可以设置小于5的数字
@property(nonatomic,assign)NSInteger barMaxItems;

//!当前选中索引
@property(nonatomic,assign)NSInteger currentIndex;

@end
